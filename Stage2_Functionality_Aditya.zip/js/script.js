
function showMessage(){alert("Thank you for joining!");}
function toggleMode(){document.body.classList.toggle("dark");}
function validateForm(){
 let n=document.getElementById("name").value;
 let e=document.getElementById("email").value;
 if(n==""||e==""){alert("All fields required");return false;}
 alert("Form submitted");return true;
}
